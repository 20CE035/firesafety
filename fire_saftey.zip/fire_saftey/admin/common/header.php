<style>
    .primary-menu-list > li > a{
            margin-right: 12px;
    }
    @media (max-width: 1599px) and (min-width: 1200px)
    {
        .pl-155 {
    padding-left: 0px;
}
    }

</style>
<!-- Main Header Area Start Here -->
        <header class="header-sticky" style="background: #c63030;">
            <div class="coustom-container">
                <div class="main-header">
                    <div class="row">
                       <!-- Logo Start Here -->
                        <div class="col-xl-2 col-lg-3 col-md-5 col-sm-6 col-5">
                            <div class="logo">
                                <a href="index.php"><h3 style="color: white;margin-top: 18%;">Fire Saftey</h3></a>
                            </div>
                        </div>
                        <!-- Logo End Here -->
                        <!-- Header Menu & Cart Area Start Here -->
                        <div class="col-xl-8 col-lg-6 d-none d-lg-block">
                            <div class="maain-menu-area maain-menu-area-three  position-relative pl-155">
                                <!-- Primary Menu Start -->
                                <div class="primary-menu">
                                    <nav>
                                        <ul class="primary-menu-list d-flex">
                                            <li class="active"><a href="admindashboard.php">Dashboard</a></li>
                                              <li><a href="noc.php">View Fire Noc</a></li>
                                              <!-- <li><a href="products.php">Add Products</a></li> -->
                                              <!-- <li><a href="view-products.php">View Products</a></li> -->
                                              <!-- <li><a href="order.php">View Products Order</a></li> -->
                                              <li><a href="contact.php">Contact</a></li>
                                              <li><a href="index.php">Logout</a></li>
                                        </ul>
                                    </nav>
                                </div>
                                <!-- Primary Menu End -->
                            </div>
                        </div>
                        <!-- Header Menu & Cart Area End Here -->
                       
                    </div>
                    <!-- Mobile Menu Start -->
                    <div class="mobile-menu d-block d-lg-none">
                        <nav>
                            <ul>
                                <li class="active"><a href="admindashboard.php">Dashboard</a></li>
                                <li><a href="noc.php">View Fire Noc</a></li>
                                <li><a href="products.php">Add Products</a></li>
                                <li><a href="view-products.php">View Products</a></li>
                                <li><a href="order.php">View Products Order</a></li>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="index.php">Logout</a></li>
                            </ul>
                        </nav>
                    </div>
                    <!-- Mobile Menu End -->
                </div>
            </div>
            <!-- Container End -->
        </header>
        <!-- Main Header Area End Here -->