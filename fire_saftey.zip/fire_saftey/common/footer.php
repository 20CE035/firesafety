<footer class="footer-section">
    <!-- Copyright Area-->
    <div class="copyright-area rmt-45">
       <div class="container">
            <div class="copyright-inner align-items-center">
                <div class="copyright-wrap order-2 order-md-1">
                    <p>Copyright © <span>2021</span> | All Rights Reserved.</p>
                    <!-- Scroll Top Button -->
                    <button class="scroll-top scroll-to-target wow fadeInUp" data-wow-duration="2s" data-target="html"><i class="fas fa-angle-double-up"></i></button>
                    <!-- footer menu -->
                </div>
                <ul class="footer-menu order-1 order-md-2">
                    
                </ul>
            </div>
        </div>
    </div>
</footer>